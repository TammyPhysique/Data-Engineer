import pandas as pd
import mysql.connector
from mysql.connector import Error

mar_data = pd.read_csv("x:/bit-academy/marathon/marathon_results.csv", delimiter = ",")

try:
    conn = mysql.connector.connect(host='localhost', user='root', password='')
    print("CSV-bestand in de MySQL-database aan het laden...")
    if conn.is_connected():
        cursor = conn.cursor()
        cursor.execute("DROP DATABASE IF EXISTS bit_academy")
        cursor.execute("CREATE DATABASE IF NOT EXISTS bit_academy")
        cursor.execute("USE bit_academy")
        cursor.execute('DROP TABLE IF EXISTS marathon;')
        cursor.execute("CREATE TABLE marathon (year INT, winner VARCHAR(255), gender VARCHAR(255), country VARCHAR(255), time TIME, marathon VARCHAR(255))")
        for x,row in mar_data.iterrows():
            sql = "INSERT INTO marathon(year,winner,gender,country,time,marathon) VALUES (%s,%s,%s,%s,%s,%s)"
            cursor.execute(sql, tuple(row))
            conn.commit()
except Error as e:
    print("Error ", e)

print("Bestand succesvol geladen!")
