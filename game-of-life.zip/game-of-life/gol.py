import pygol
# Voor deze opdracht heb je de module `pygol` nodig.
# (version 1.2 should work)
# https://pypi.org/project/pygol/

pygol.rungame()
